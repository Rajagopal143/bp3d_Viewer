{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.7 Exporter",
		"vertices"      : 8,
		"faces"         : 6,
		"normals"       : 8,
		"colors"        : 0,
		"uvs"           : [4],
		"materials"     : 1,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [	{
		"DbgColor" : 15658734,
		"DbgIndex" : 0,
		"DbgName" : "bake_mat.013",
		"blending" : "NormalBlending",
		"colorAmbient" : [1.0, 1.0, 1.0],
		"colorDiffuse" : [1.0, 1.0, 1.0],
		"colorEmissive" : [0.0, 0.0, 0.0],
		"colorSpecular" : [0.5, 0.5, 0.5],
		"depthTest" : true,
		"depthWrite" : true,
		"mapDiffuse" : "https://lh3.googleusercontent.com/u/0/drive-viewer/AKGpihYrhf-P6TmMX7TfcVVtIC7It-lHkic8AoI-9F8Rk1_Q6bpWMmARwsqF8oqoaXCru4AvqPycnfBpKKhYmqC7FDtZrg-qzi7F0VY=w1366-h635",
		"mapDiffuseWrap" : ["repeat", "repeat"],
		"shading" : "Lambert",
		"specularCoef" : 50,
		"transparency" : 1.0,
		"transparent" : false,
		"vertexColors" : false
	}],

	"vertices" : [-76.2,-0.249995,121.92,-76.2,-0.250005,-121.92,76.2,-0.250005,-121.92,76.2,-0.249995,121.92,-76.2,0.250005,121.92,-76.2,0.249995,-121.92,76.2,0.249995,-121.92,76.2,0.250005,121.92],

	"morphTargets" : [],

	"normals" : [-0.577349,-0.577349,-0.577349,-0.577349,-0.577349,0.577349,-0.577349,0.577349,0.577349,-0.577349,0.577349,-0.577349,0.577349,0.577349,-0.577349,0.577349,-0.577349,-0.577349,0.577349,0.577349,0.577349,0.577349,-0.577349,0.577349],

	"colors" : [],

	"uvs" : [[-2e-06,0.999998,2e-06,-2e-06,1,2e-06,0.999998,1]],

	"faces" : [43,1,0,4,5,0,0,1,2,3,0,1,2,3,43,5,6,2,1,0,2,3,0,1,3,4,5,0,43,6,7,3,2,0,2,3,0,1,4,6,7,5,43,0,3,7,4,0,0,1,2,3,1,7,6,2,43,0,1,2,3,0,2,3,0,1,1,0,5,7,43,7,6,5,4,0,2,3,0,1,6,4,3,2],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

  "animations" : []


}
